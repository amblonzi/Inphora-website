"use client";

import React from 'react';
import { Icons } from './Icons';

interface SidebarProps {
    activeView: string;
    setActiveView: (view: string) => void;
}

export default function Sidebar({ activeView, setActiveView }: SidebarProps) {
    const menuItems = [
        { id: 'hero', label: 'Home', icon: <Icons.Home className="w-5 h-5" /> },
        { id: 'solutions', label: 'Solutions', icon: <Icons.Brain className="w-5 h-5" /> },
        { id: 'approach', label: 'Approach', icon: <Icons.List className="w-5 h-5" /> },
        { id: 'contact', label: 'Connect', icon: <Icons.Phone className="w-5 h-5" /> },
    ];

    return (
        <aside className="w-20 md:w-64 bg-primary h-screen fixed left-0 top-0 z-50 flex flex-col border-r border-white/5 transition-all duration-300">
            {/* Logo Section */}
            <div className="p-6 md:p-8 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-primary shrink-0 shadow-lg shadow-white/5">
                    <span className="italic font-black text-secondary text-xl">i</span>
                </div>
                <span className="text-white font-bold text-xl tracking-tight hidden md:block">
                    Inphora<span className="text-secondary">.</span>
                </span>
            </div>

            {/* Navigation Section */}
            <nav className="flex-grow px-4 md:px-6 py-8 space-y-2">
                {menuItems.map((item) => (
                    <button
                        key={item.id}
                        onClick={() => setActiveView(item.id)}
                        className={`w-full flex items-center gap-4 px-4 py-4 rounded-xl transition-all duration-300 group ${
                            activeView === item.id 
                            ? 'bg-secondary text-primary shadow-lg shadow-secondary/20' 
                            : 'text-slate-400 hover:bg-white/5 hover:text-white'
                        }`}
                    >
                        <div className={`shrink-0 transition-transform duration-300 ${activeView === item.id ? 'scale-110' : 'group-hover:scale-110'}`}>
                            {item.icon}
                        </div>
                        <span className={`font-bold text-sm hidden md:block transition-all ${activeView === item.id ? 'translate-x-0' : 'group-hover:translate-x-1'}`}>
                            {item.label}
                        </span>
                    </button>
                ))}
            </nav>

            {/* Footer Section */}
            <div className="p-6 md:p-8 mt-auto border-t border-white/5">
                <div className="hidden md:block">
                    <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-black mb-1">Status</div>
                    <div className="flex items-center gap-2 text-xs text-white font-bold">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Live Systems
                    </div>
                </div>
                <div className="md:hidden flex justify-center">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                </div>
            </div>
        </aside>
    );
}
