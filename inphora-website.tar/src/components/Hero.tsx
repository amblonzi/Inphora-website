"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { Icons } from './Icons';

export default function Hero() {
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setMounted(true);
        const handleMouseMove = (e: MouseEvent) => {
            setMousePos({
                x: (e.clientX / window.innerWidth - 0.5) * 20,
                y: (e.clientY / window.innerHeight - 0.5) * 20,
            });
        };
        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    return (
        <section className="relative h-full flex items-center justify-center overflow-hidden bg-white p-6 md:p-12">
            {/* Background Grid */}
            <div className="absolute inset-0 grid-background opacity-50 pointer-events-none" />

            {/* Floating 3D Asset */}
            <div
                className="absolute inset-0 z-0 flex items-center justify-center opacity-30 pointer-events-none"
                style={{
                    transform: `translate(${mousePos.x}px, ${mousePos.y}px)`,
                }}
            >
                <div className="relative w-full max-w-4xl aspect-square">
                    {mounted && (
                        <Image
                            src="/images/hero-abstract.png"
                            alt="Abstract 3D Shape"
                            fill
                            className="object-contain animate-[float_10s_ease-in-out_infinite]"
                            priority
                        />
                    )}
                </div>
            </div>

            <div className="container mx-auto relative z-10">
                <div className="max-w-4xl mx-auto text-center">
                    <div
                        data-aos="fade-up"
                        className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/10 bg-primary/5 text-xs font-black text-primary mb-8 uppercase tracking-widest"
                    >
                        Enterprise Intelligence
                    </div>

                    <h1
                        data-aos="fade-up"
                        data-aos-delay="100"
                        className="text-5xl md:text-8xl font-black leading-[1.1] mb-8 text-primary tracking-tighter"
                    >
                        Digital <br />
                        <span className="text-secondary">Architecture</span>
                    </h1>

                    <p
                        data-aos="fade-up"
                        data-aos-delay="200"
                        className="text-xl md:text-2xl text-slate-700 max-w-2xl mx-auto mb-12 leading-relaxed font-sans font-bold"
                    >
                        Engineering high-performance software ecosystems
                        for industry leaders.
                    </p>

                    <div
                        data-aos="fade-up"
                        data-aos-delay="300"
                        className="flex flex-col sm:flex-row items-center justify-center gap-4"
                    >
                        <a
                            href="https://wa.me/254705522155"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-10 py-5 bg-primary text-white font-black rounded-2xl hover:bg-slate-800 transition-all shadow-xl flex items-center justify-center gap-3 text-lg"
                        >
                            <Icons.WhatsApp width={24} height={24} />
                            Consult
                        </a>
                        <a
                            href="mailto:contact@inphora.net"
                            className="px-10 py-5 bg-white border-2 border-primary/10 text-primary font-black rounded-2xl hover:bg-slate-50 transition-all flex items-center justify-center gap-3 text-lg"
                        >
                            <Icons.Mail width={24} height={24} />
                            Contact
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
}
