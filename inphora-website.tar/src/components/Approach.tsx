import React from 'react';

const steps = [
    {
        num: "01",
        title: "Discovery",
        text: "We listen to your needs and understand your business goals first."
    },
    {
        num: "02",
        title: "Development",
        text: "We build your solution using modern, secure, and clear coding standards."
    },
    {
        num: "03",
        title: "Launch",
        text: "We test everything thoroughly ensuring a smooth launch with no surprises."
    }
];

export default function Approach() {
    return (
        <section id="approach" className="h-full overflow-y-auto p-8 md:p-16 bg-slate-50">
            <div className="container mx-auto">
                <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                    <div data-aos="fade-right">
                        <h2 className="text-sm font-black text-secondary tracking-[0.2em] uppercase mb-4">Our Methodology</h2>
                        <h3 className="text-4xl md:text-6xl font-black text-primary mb-8 leading-tight tracking-tighter">Precision <br /> Development</h3>
                        <p className="text-slate-700 text-lg md:text-xl mb-10 leading-relaxed font-sans font-bold">
                            Our rigorous development lifecycle ensures that every line of code serves a measurable business objective.
                        </p>
                        <div className="flex justify-center lg:justify-start">
                            <button className="px-10 py-4 bg-primary text-white font-black rounded-2xl hover:bg-slate-800 transition-all shadow-xl">
                                System Overview
                            </button>
                        </div>
                    </div>

                    <div className="space-y-8 md:space-y-12">
                        {steps.map((step, index) => (
                            <div
                                key={index}
                                data-aos="fade-left"
                                data-aos-delay={index * 150}
                                className="flex gap-8 items-start group p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:shadow-lg transition-all"
                            >
                                <div className="text-4xl md:text-5xl font-black text-slate-200 font-display transition-colors group-hover:text-secondary">
                                    {step.num}
                                </div>
                                <div className="pt-2">
                                    <h4 className="text-xl md:text-2xl font-black text-primary mb-3">{step.title}</h4>
                                    <p className="text-slate-600 font-sans leading-relaxed text-base md:text-lg font-bold">
                                        {step.text}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}
