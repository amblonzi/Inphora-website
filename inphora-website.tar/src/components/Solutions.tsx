import React from 'react';
import { Icons } from './Icons';

const services = [
    {
        title: "AI & Data Insights",
        description: "Turn your data into clear answers. We help you make smarter decisions with custom data tools.",
        icon: <Icons.Brain className="w-8 h-8" />,
    },
    {
        title: "Custom Software Development",
        description: "Reliable software built to last. From financial systems to custom web apps, we build exactly what you need.",
        icon: <Icons.Code className="w-8 h-8" />,
    },
    {
        title: "Security & Protection",
        description: "Keep your business safe. We test and secure your systems against threats so you can work with peace of mind.",
        icon: <Icons.Shield className="w-8 h-8" />,
    },
    {
        title: "Cloud Hosting & Support",
        description: "Fast and secure hosting. We ensure your website and apps are always online and running smoothly.",
        icon: <Icons.Cloud className="w-8 h-8" />,
    },
];

export default function Solutions() {
    return (
        <section id="solutions" className="h-full overflow-y-auto p-8 md:p-16 bg-white">
            <div className="container mx-auto">
                <div className="mb-12 md:mb-16" data-aos="fade-up">
                    <h2 className="text-sm font-black text-secondary tracking-[0.2em] uppercase mb-4">Industrial Intelligence</h2>
                    <h3 className="text-4xl md:text-6xl font-black text-primary mb-6 tracking-tight">Core Solutions</h3>
                    <p className="text-slate-600 max-w-2xl text-lg md:text-xl font-bold leading-relaxed">
                        Precision-engineered frameworks for modern data challenges.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                    {services.map((service, index) => (
                        <div
                            key={index}
                            data-aos="fade-up"
                            data-aos-delay={index * 100}
                            className="group p-8 md:p-10 rounded-3xl bg-slate-50 border border-slate-100 hover:border-primary/20 transition-all duration-300 hover:bg-white hover:shadow-2xl hover:shadow-primary/5 flex flex-col"
                        >
                            <div className="w-16 h-16 rounded-2xl bg-primary text-secondary flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-lg shadow-primary/10">
                                {service.icon}
                            </div>
                            <h4 className="text-2xl md:text-3xl font-black text-primary mb-4">{service.title}</h4>
                            <p className="text-slate-600 leading-relaxed font-sans font-bold text-base md:text-lg mb-8 flex-grow">
                                {service.description}
                            </p>

                            <div className="flex items-center gap-6 pt-8 border-t border-slate-200">
                                <a
                                    href={`https://wa.me/254705522155?text=I'm%20interested%20in%20Inphora's%20${encodeURIComponent(service.title)}%20solutions.`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="px-6 py-3 rounded-xl bg-primary text-white text-sm font-black hover:bg-slate-800 transition-all flex items-center gap-2"
                                >
                                    <Icons.WhatsApp width={18} height={18} />
                                    Inquiry
                                </a>
                                <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black ml-auto">Verified Service</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
